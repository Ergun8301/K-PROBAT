# Handoff : Site vitrine K-ProBat (maçonnerie)

## Vue d'ensemble
Site vitrine one-page pour K-ProBat, artisan maçon à Montagnat (01). Objectif : présenter le savoir-faire, montrer les réalisations en photos, obtenir des demandes de devis (WhatsApp / e-mail / téléphone).

## À propos des fichiers de design
`K-ProBat - Maquette.html` est une **référence de design créée en HTML** : un prototype autonome (toutes les photos sont embarquées en base64, il s'ouvre hors ligne dans n'importe quel navigateur). Ce n'est **pas du code de production à copier tel quel**. La mission : **recréer ce design** dans un vrai environnement web (site statique HTML/CSS propre, Astro, Next.js… au choix selon le projet), avec les photos en fichiers séparés optimisés (WebP) au lieu du base64.

## Fidélité
**Haute fidélité (hifi)** : couleurs, typographies, espacements, textes et interactions sont finaux. Reproduire fidèlement, au pixel près. Ne pas réécrire les textes.

## Écrans / sections (one-page, dans l'ordre)
1. **`#hero` — Accueil** : plein écran (min-height 100vh), fond #1A1713. Mosaïque de 6 photos de chantier en fond avec voile dégradé sombre pour la lisibilité. Barre du haut : « K-PROBAT » (800, 15px, uppercase, #EAE3D4) + nav. Au centre/bas : grand titre K-PROBAT centré, slogan « Bâti pour durer » en dessous.
2. **`#savoirfaire` — 02 / Savoir-faire** : liste des prestations. Padding vertical clamp(70px,10vw,140px).
3. **`#realisations` — Réalisations** : galerie de photos réelles de chantiers (escalier béton hélicoïdal, clôtures, Siporex, fondations, briques, dalles). Sur desktop : effet au survol (désaturation levée) ; sur mobile (<860px) : photos affichées pleinement colorées dès le chargement, sans effet hover.
4. **`#artisan` — 03 / L'artisan** : section sombre inversée, fond #221E19, texte #EAE3D4.
5. **`#contact` — 04 / Contact — Devis gratuit** : titre « Un chantier en tête ? » + coordonnées + **formulaire de contact sans serveur** (voir Interactions).

Étiquette de section : petit surtitre mono (IBM Plex Mono, 11px, letter-spacing .3em, couleur accent #D93916), ex. « 03 / L'ARTISAN ».

## Interactions & comportement
- **Apparition au scroll** : éléments `data-reveal` / `data-fade` révélés à l'entrée dans le viewport ; colonnes de photos légèrement inclinées pendant le scroll (effet « tilt »).
- **Formulaire de contact (sans backend)** : champs Nom, Téléphone, Type de travaux (select : Gros œuvre / fondations, Coffrage & béton armé, Briques / parpaings, Béton cellulaire — Siporex, Escalier béton, Piscine maçonnée, Clôture / piliers, Terrasse / dalle, Autre), Message. Style des champs : fond transparent, seulement une bordure basse 1px rgba(34,30,25,.35), focus → bordure basse #D93916.
  - Bouton « Envoyer sur WhatsApp » (#25D366, hover #1DA851) : ouvre `https://wa.me/33652373293?text=<message pré-rempli>` (« Bonjour, je souhaite un devis gratuit. » + Nom / Téléphone / Travaux / Projet, un par ligne).
  - Bouton « Envoyer par e-mail » (#221E19, hover #D93916) : `mailto:k.probat01@gmail.com` avec sujet « Demande de devis — <nom> » et même corps.
  - Mention : « RÉPONSE SOUS 24 H — MONTAGNAT & 30 KM ».
  - Si le site cible dispose d'un backend, on peut remplacer par un vrai envoi de formulaire, en gardant les deux boutons comme raccourcis.
- **Bouton WhatsApp flottant** en bas de page.
- Boutons : angles droits (pas de border-radius), padding 18px 30px, 700, 14px, letter-spacing .04em, transition background .3s.
- **Responsive** : bascule mobile à 860px. Cibles tactiles ≥ 44px.

## Tokens de design
- Couleurs : encre #221E19 · fond crème #EAE3D4 · fond hero #1A1713 · accent rouge #D93916 (var `--acc`) · WhatsApp #25D366 (hover #1DA851) · texte secondaire rgba(34,30,25,.55–.6).
- Typo : **League Spartan** (titres 900 uppercase, letter-spacing négatif ~-.015em, line-height .95 ; corps 500) + **IBM Plex Mono** (surtitres, labels, mentions ; letter-spacing .12–.3em). Google Fonts.
- Échelles fluides en `clamp()` : titres h2 clamp(30px,5vw,68px) ; padding sections clamp(70px,10vw,140–160px) vertical, clamp(18px,4vw,48px) horizontal.

## Coordonnées (exactes, ne pas modifier)
Tél. 06 52 37 32 93 (`tel:0652373293`) · WhatsApp `https://wa.me/33652373293` · k.probat01@gmail.com · 416 chemin des Buffets — 01250 Montagnat.

## Assets
Toutes les photos de chantier sont embarquées en base64 dans le HTML — les extraire (ou redemander les originaux au client) et les servir en fichiers optimisés dans la vraie implémentation.

## Fichiers
- `K-ProBat - Maquette.html` — la maquette autonome complète (référence unique ; s'ouvre dans un navigateur).
